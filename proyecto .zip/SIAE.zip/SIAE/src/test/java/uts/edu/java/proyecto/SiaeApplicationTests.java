package uts.edu.java.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiaeApplicationTests {

	@Test
	void contextLoads() {
	}

}
