package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Docente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para la entidad Docente.
 * La clave primaria es 'identificacion' (String).
 */
@Repository
public interface DocenteRepositorio extends JpaRepository<Docente, String> {
    
}