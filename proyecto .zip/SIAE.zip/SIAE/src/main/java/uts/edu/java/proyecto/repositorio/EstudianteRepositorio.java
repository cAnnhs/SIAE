package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Estudiante; // Debe importar tu modelo
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * JpaRepository<Modelo, TipoDatoPK>
 * Esto hereda automáticamente los métodos: findAll(), save(), findById(), deleteById(), etc.
 */
@Repository
public interface EstudianteRepositorio extends JpaRepository<Estudiante, String> {
    
    // Si esta interfaz extiende JpaRepository correctamente, 
    // tu servicio dejará de marcar error al usar findAll() o save().

}