package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Administrativo;
import uts.edu.java.proyecto.repositorio.AdministrativoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministrativoServicio implements IAdministrativoServicio {

    @Autowired
    private AdministrativoRepositorio administrativoRepositorio;

    @Override
    public List<Administrativo> findAll() {
        return administrativoRepositorio.findAll();
    }

    @Override
    public Administrativo save(Administrativo administrativo) {
        return administrativoRepositorio.save(administrativo);
    }

    @Override
    public Optional<Administrativo> findById(String identificacion) {
        return administrativoRepositorio.findById(identificacion);
    }

    @Override
    public void deleteById(String identificacion) {
        administrativoRepositorio.deleteById(identificacion);
    }
}
