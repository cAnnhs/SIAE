package uts.edu.java.proyecto.modelo;

import jakarta.persistence.Entity; 
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "directivos")
public class Directivo {

	@Id
    private String identificacion;
    private String nombreCompleto;
    private String rolTitulo;
    private String unidadFacultad;
    private String correoInstitucional;

    // Constructor vacío
    public Directivo() {
    }

    // Constructor con todos los campos
    public Directivo(String identificacion, String nombre_completo, String rol_titulo, String unidad_facultad, String correo_institucional) {
        this.identificacion = identificacion;
        this.nombreCompleto = nombre_completo;
        this.rolTitulo = rol_titulo;
        this.unidadFacultad = unidad_facultad;
        this.correoInstitucional = correo_institucional;
    }

    // Getters y Setters
    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getRolTitulo() {
        return rolTitulo;
    }

    public void setRolTitulo(String rolTitulo) {
        this.rolTitulo = rolTitulo;
    }

    public String getUnidadFacultad() {
        return unidadFacultad;
    }

    public void setUnidadFacultad(String unidadFacultad) {
        this.unidadFacultad = unidadFacultad;
    }

    public String getCorreoInstitucional() {
        return correoInstitucional;
    }

    public void setCorreoInstitucional(String correoInstitucional) {
        this.correoInstitucional = correoInstitucional;
    }
}
