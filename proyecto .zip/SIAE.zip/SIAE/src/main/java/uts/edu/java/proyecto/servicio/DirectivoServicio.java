package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Directivo;
import uts.edu.java.proyecto.repositorio.DirectivoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DirectivoServicio implements IDirectivoServicio {

    @Autowired
    private DirectivoRepositorio directivoRepositorio;

    @Override
    public List<Directivo> findAll() {
        return directivoRepositorio.findAll();
    }

    @Override
    public Directivo save(Directivo directivo) {
        return directivoRepositorio.save(directivo);
    }

    @Override
    public Optional<Directivo> findById(String identificacion) {
        return directivoRepositorio.findById(identificacion);
    }

    @Override
    public void deleteById(String identificacion) {
        directivoRepositorio.deleteById(identificacion);
    }
}
