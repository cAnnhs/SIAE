package uts.edu.java.proyecto.modelo;

import jakarta.persistence.Entity; 
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity // <-- ¡Asegúrate de que esta anotación esté presente!
@Table(name = "administrativos")
public class Administrativo {

    @Id
    private String identificacion;
    private String nombreCompleto;
    private String dependencia;
    private String cargo;
    private String correo;

    // Constructor vacío
    public Administrativo() {
    }

    // Constructor con todos los campos
    public Administrativo(String identificacion, String nombre_completo, String dependencia, String cargo, String correo) {
        this.identificacion = identificacion;
        this.nombreCompleto = nombre_completo;
        this.dependencia = dependencia;
        this.cargo = cargo;
        this.correo = correo;
    }

    // Getters y Setters
    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getDependencia() {
        return dependencia;
    }

    public void setDependencia(String dependencia) {
        this.dependencia = dependencia;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}