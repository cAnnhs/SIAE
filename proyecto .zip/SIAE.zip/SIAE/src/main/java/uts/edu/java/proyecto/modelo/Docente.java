package uts.edu.java.proyecto.modelo;

import jakarta.persistence.Entity; 
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "docentes")
public class Docente {

	@Id
    private String identificacion;
    private String nombreCompleto;
    private String departamentoArea;
    private String tipoContrato;
    private String correoInstitucional;

    // Constructor vacío
    public Docente() {
    }

    // Constructor con todos los campos
    public Docente(String identificacion, String nombre_completo, String departamento_area, String tipo_contrato, String correo_institucional) {
        this.identificacion = identificacion;
        this.nombreCompleto = nombre_completo;
        this.departamentoArea = departamento_area;
        this.tipoContrato = tipo_contrato;
        this.correoInstitucional = correo_institucional;
    }

    // Getters y Setters
    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getDepartamentoArea() {
        return departamentoArea;
    }

    public void setDepartamentoArea(String departamentoArea) {
        this.departamentoArea = departamentoArea;
    }

    public String getTipoContrato() {
        return tipoContrato;
    }

    public void setTipoContrato(String tipoContrato) {
        this.tipoContrato = tipoContrato;
    }

    public String getCorreoInstitucional() {
        return correoInstitucional;
    }

    public void setCorreoInstitucional(String correoInstitucional) {
        this.correoInstitucional = correoInstitucional;
    }
}