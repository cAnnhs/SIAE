package uts.edu.java.proyecto.servicio;


import uts.edu.java.proyecto.modelo.Estudiante;
import java.util.List;
import java.util.Optional;

public interface IEstudianteServicio {

    List<Estudiante> findAll();
    Estudiante save(Estudiante estudiante);
    Optional<Estudiante> findById(String codigo);
    void deleteById(String codigo);
}