package uts.edu.java.proyecto.controlador;

import uts.edu.java.proyecto.modelo.Administrativo; // Asume que tienes este modelo
import uts.edu.java.proyecto.servicio.AdministrativoServicio; // Asume que tienes este servicio
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/views/administrador")
public class AdministrativoController {

    @Autowired
    private AdministrativoServicio administrativoServicio; // Inyección del servicio

    /**
     * Muestra la lista de personal administrativo.
     * La lista se llamará 'listaAdministrativos' en el modelo.
     * @param model Objeto para pasar datos a la vista.
     * @return Nombre del archivo HTML.
     */
    @GetMapping("/")
    public String listarAdministrativo(Model model) {
        // Simula la obtención de datos desde el servicio
        List<Administrativo> listaAdministrativo = administrativoServicio.findAll(); 
        
        model.addAttribute("listaAdministrativo", listaAdministrativo);
        
        // Retorna el nombre de la plantilla: 'administrativo/lista.html'
        return "views/administrador/administrativo"; 
    }

}