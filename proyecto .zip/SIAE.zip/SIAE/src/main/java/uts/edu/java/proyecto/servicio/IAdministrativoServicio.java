package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Administrativo;
import java.util.List;
import java.util.Optional;

public interface IAdministrativoServicio {

    List<Administrativo> findAll();
    Administrativo save(Administrativo administrativo);
    Optional<Administrativo> findById(String identificacion);
    void deleteById(String identificacion);
}
