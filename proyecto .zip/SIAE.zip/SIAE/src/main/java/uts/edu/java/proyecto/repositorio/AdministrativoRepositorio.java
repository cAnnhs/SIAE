package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Administrativo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para la entidad Administrativo.
 * La clave primaria es 'identificacion' (String).
 */
@Repository
public interface AdministrativoRepositorio extends JpaRepository<Administrativo, String> {
    
}