package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Docente;
import java.util.List;
import java.util.Optional;

public interface IDocenteServicio {

    List<Docente> findAll();
    Docente save(Docente docente);
    Optional<Docente> findById(String identificacion);
    void deleteById(String identificacion);
}
