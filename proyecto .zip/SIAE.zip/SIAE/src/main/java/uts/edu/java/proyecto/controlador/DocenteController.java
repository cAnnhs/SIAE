package uts.edu.java.proyecto.controlador;

import uts.edu.java.proyecto.modelo.Docente; // Asume que tienes este modelo
import uts.edu.java.proyecto.servicio.DocenteServicio; // Asume que tienes este servicio
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/views/docente")
public class DocenteController {

    @Autowired
    private DocenteServicio docenteServicio; // Inyección del servicio

    /**
     * Muestra la lista de docentes.
     * La lista se llamará 'listaDocentes' en el modelo.
     * @param model Objeto para pasar datos a la vista.
     * @return Nombre del archivo HTML.
     */
    @GetMapping("/")
    public String listarDocentes(Model model) {
        // Simula la obtención de datos desde el servicio
        List<Docente> listaDocentes = docenteServicio.findAll(); 
        
        model.addAttribute("listaDocentes", listaDocentes);
        
        // Retorna el nombre de la plantilla: 'docente/lista.html'
        return "views/docente/docente"; 
    }

}