package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Estudiante;
import uts.edu.java.proyecto.repositorio.EstudianteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteServicio implements IEstudianteServicio {

    @Autowired
    private EstudianteRepositorio estudianteRepositorio;

    @Override
    public List<Estudiante> findAll() {
        return estudianteRepositorio.findAll();
    }

    @Override
    public Estudiante save(Estudiante estudiante) {
        return estudianteRepositorio.save(estudiante);
    }

    @Override
    public Optional<Estudiante> findById(String codigo) {
        return estudianteRepositorio.findById(codigo);
    }

    @Override
    public void deleteById(String codigo) {
        estudianteRepositorio.deleteById(codigo);
    }
}