package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Directivo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para la entidad Directivo.
 * La clave primaria es 'identificacion' (String).
 */
@Repository
public interface DirectivoRepositorio extends JpaRepository<Directivo, String> {
    
}
