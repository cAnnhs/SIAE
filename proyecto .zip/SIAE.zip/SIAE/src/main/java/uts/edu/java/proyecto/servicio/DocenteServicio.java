package uts.edu.java.proyecto.servicio;


import uts.edu.java.proyecto.modelo.Docente;
import uts.edu.java.proyecto.repositorio.DocenteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocenteServicio implements IDocenteServicio {

    @Autowired
    private DocenteRepositorio docenteRepositorio;

    @Override
    public List<Docente> findAll() {
        return docenteRepositorio.findAll();
    }

    @Override
    public Docente save(Docente docente) {
        return docenteRepositorio.save(docente);
    }

    @Override
    public Optional<Docente> findById(String identificacion) {
        return docenteRepositorio.findById(identificacion);
    }

    @Override
    public void deleteById(String identificacion) {
        docenteRepositorio.deleteById(identificacion);
    }
}
