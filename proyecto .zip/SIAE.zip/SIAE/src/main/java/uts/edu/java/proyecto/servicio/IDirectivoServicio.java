package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Directivo;
import java.util.List;
import java.util.Optional;

public interface IDirectivoServicio {

    List<Directivo> findAll();
    Directivo save(Directivo directivo);
    Optional<Directivo> findById(String identificacion);
    void deleteById(String identificacion);
}
