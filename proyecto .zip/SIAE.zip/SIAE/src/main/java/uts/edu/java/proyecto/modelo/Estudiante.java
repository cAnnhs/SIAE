package uts.edu.java.proyecto.modelo;

import jakarta.persistence.Entity; 
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "estudiantes")
public class Estudiante { 


	@Id
    private String codigo;
    private String nombreCompleto;
    private String programa;
    private String telefono;
    private String correoInstitucional;

    // Constructor vacío (necesario para frameworks como Spring/JPA)
    public Estudiante() {
    }

    // Constructor con todos los campos
    public Estudiante(String codigo, String nombre_completo, String programa, String telefono, String correo_institucional) {
        this.codigo = codigo;
        this.nombreCompleto = nombre_completo;
        this.programa = programa;
        this.telefono = telefono;
        this.correoInstitucional = correo_institucional;
    }

    // Getters y Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreoInstitucional() {
        return correoInstitucional;
    }

    public void setCorreoInstitucional(String correoInstitucional) {
        this.correoInstitucional = correoInstitucional;
    }
}